namespace Lumafly.Models;

public record ValidPath(string Root, string Suffix);