﻿namespace Lumafly.Enums;

public enum LumaflyMode
{
    Online,
    Offline,
}