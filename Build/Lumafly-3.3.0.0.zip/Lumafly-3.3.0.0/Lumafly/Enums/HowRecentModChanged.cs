﻿namespace Lumafly.Enums;

public enum HowRecentModChanged
{
    Month = 0,
    Week = 1,
}