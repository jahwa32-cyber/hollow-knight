﻿namespace Lumafly.Enums;

public enum AutoRemoveUnusedDepsOptions
{
    Never,
    Ask,
    Always,
}