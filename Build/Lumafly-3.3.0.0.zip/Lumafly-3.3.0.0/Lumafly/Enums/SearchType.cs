﻿namespace Lumafly.Enums;

public enum SearchType
{
    Normal,
    DependencyAndIntegration,
    Integration
}