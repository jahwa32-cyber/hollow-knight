﻿namespace Lumafly.Enums;

public enum ModChangeState
{
    None = 0,
    Updated = 1,
    New = 2,
}