﻿namespace Lumafly.Enums;

public enum HttpSetting
{
    OnlyWorkaround,
    TryBoth,
}