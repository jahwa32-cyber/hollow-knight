﻿namespace Lumafly.Enums;

public enum ModFilterState
{
    All,
    Installed,
    Enabled,
    OutOfDate,
    WhatsNew,
}