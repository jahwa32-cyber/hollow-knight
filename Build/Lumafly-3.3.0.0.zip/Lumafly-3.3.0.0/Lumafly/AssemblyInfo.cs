using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Lumafly.Tests")]