﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Lumafly.Views.Pages;

public partial class SearchOptionsMenu : UserControl
{
    public SearchOptionsMenu()
    {
        InitializeComponent();
    }
}