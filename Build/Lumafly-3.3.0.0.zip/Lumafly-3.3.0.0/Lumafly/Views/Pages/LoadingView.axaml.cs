﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Lumafly.Views.Pages;

public partial class LoadingView : UserControl
{
    public LoadingView()
    {
        InitializeComponent();
    }
}